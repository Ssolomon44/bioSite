# CSD 340 Web Development with HTML and CSS

## Contributors
- Instructor: Chandra Bobba
- Student: Shayna Solomon
